package com.freebasicacc.services;

import com.freebasicacc.util.FileUtil;
import java.io.FileInputStream;
import java.util.Properties;


public class LogService {
    
    /*public void intiallizeLogger() throws Exception{
       Properties logProperties = new Properties();
       logProperties.load(new FileInputStream(FileUtil.getCurrentJarPath()+"/config/log4j.properties"));
      
       PropertyConfigurator.configure(logProperties);
    }*/
}